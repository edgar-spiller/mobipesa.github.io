// Fetch Instagram posts using JavaScript
fetch('https://graph.instagram.com/v12.0/{user-id}/media?access_token={access-token}')
.then(response => response.json())
.then(data => {
  const feedElement = document.getElementById('instagram-feed');
  data.data.forEach(post => {
    const imageUrl = post.media_type === 'IMAGE' ? post.media_url : post.thumbnail_url;
    const caption = post.caption ? post.caption : 'No caption';

    // Create HTML elements to display the post
    const postElement = document.createElement('div');
    postElement.innerHTML = `
      <img src="${imageUrl}" alt="${caption}">
      <p>${caption}</p>
    `;
    feedElement.appendChild(postElement);
  });
})
.catch(error => console.error(error));