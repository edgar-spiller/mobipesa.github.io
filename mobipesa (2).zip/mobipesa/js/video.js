    document.addEventListener('DOMContentLoaded', function () {
    const openVideoBtn = document.getElementById('openVideoBtn');
    const closeVideoBtn = document.getElementById('closeVideoBtn');
    const videoPanel = document.getElementById('videoPanel');
    const videoPlayer = document.getElementById('videoPlayer');
  
    openVideoBtn.addEventListener('click', function () {
      videoPanel.classList.remove('hiddens');
    });
  
    closeVideoBtn.addEventListener('click', function () {
      videoPanel.classList.add('hiddens');
      // Pause the video when the panel is closed
      videoPlayer.pause();
    });
  });

  function toggleVideoPanel() {
    const videoPanel = document.getElementById('videoPanel');
    videoPanel.classList.toggle('hiddens');
  }
  
  
  
  