function submitForm() {
    // Perform form submission logic here
    
    // For example, after form submission:
    displayResponse("successfully submitted!");
}

function displayResponse(message) {
    var responseElement = document.getElementById("response");
    responseElement.innerHTML = message;
    responseElement.classList.remove("hidden");
}

